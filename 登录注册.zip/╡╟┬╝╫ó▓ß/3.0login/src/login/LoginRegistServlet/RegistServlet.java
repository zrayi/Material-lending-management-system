package login.LoginRegistServlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import login.mysql.UserDao;

import java.util.regex.Matcher;  
import java.util.regex.Pattern;  

public class RegistServlet extends HttpServlet {
	/** 
	 * 大陆手机号码11位数，匹配格式：前三位固定格式+后8位任意数 
	 * 此方法中前三位格式有： 
	 * 13+任意数 
	 * 15+除4的任意数 
	 * 18+除1和4的任意数 
	 * 17+除9的任意数 
	 * 147 
	 */  
	//判断输入的用户名是否为电话号码
		public static boolean isPhoneLegal(String string){
	    String regExp = "^((13[0-9])|(15[^4])|(18[0,2,3,5-9])|(17[0-8])|(147))\\d{8}$";  
	    Pattern p = Pattern.compile(regExp);  
	    Matcher m = p.matcher(string);  
	    if (m.matches())
        return true;
	    else
        return false; 
		}  
//判断输入的用户名是否为电子邮箱
		public static boolean isEmail(String string) {
	    String regExp = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";
	    Pattern p;
	    Matcher m;
	    p = Pattern.compile(regExp);
	    m = p.matcher(string);
	    if (m.matches())
	        return true;
	    else
	        return false;
		}
//判断输入的密码长度和组成方式
		public static boolean isLength (String string){
			String regExp = "^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,20}$";
			Pattern p;
			Matcher m;
		  p = Pattern.compile(regExp);
	    m = p.matcher(string);
	    if (m.matches())
	        return true;
	    else
	        return false;
			}
		
		private static final long serialVersionUID = 1L;

		public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html;charset=utf-8");
			String userName = request.getParameter("userName");
			String passkey = request.getParameter("passkey");
			String rePasskey = request.getParameter("rePasskey");
			String yanzhengma = request.getParameter("yanzhengma");
			String department = request.getParameter("department");
			String realName = request.getParameter("realName");
			String stuNumber = request.getParameter("stuNumber");
			String academy = request.getParameter("academy");
			String phoneNumber = request.getParameter("phoneNumber");
			
			//注册的逻辑控制
			
			if(userName==null||userName.trim().isEmpty()){
				request.setAttribute("msg", "帐号不能为空");
				request.getRequestDispatcher("/regist.jsp").forward(request, response);
				return;
			}
			
			if(!isPhoneLegal(userName)&&!isEmail(userName)) {
				request.setAttribute("msg", "手机号或邮箱错误");
				request.getRequestDispatcher("/regist.jsp").forward(request, response);
				return;
			}
	
			if(yanzhengma==null||yanzhengma.trim().isEmpty()){
				request.setAttribute("msg1", "验证码错误");
				request.getRequestDispatcher("/regist.jsp").forward(request, response);
				return;
			}
			
			if(department==null||department.trim().isEmpty()){
				request.setAttribute("msg2", "部门不能为空");
				request.getRequestDispatcher("/regist.jsp").forward(request, response);
				return;
			}
			
			if(realName==null||realName.trim().isEmpty()){
				request.setAttribute("msg3", "姓名不能为空");
				request.getRequestDispatcher("/regist.jsp").forward(request, response);
				return;
			}
			
			if(stuNumber==null||stuNumber.trim().isEmpty()){
				request.setAttribute("msg4", "学号不能为空");
				request.getRequestDispatcher("/regist.jsp").forward(request, response);
				return;
			}
			
			if(academy==null||academy.trim().isEmpty()){
				request.setAttribute("msg5", "学院不能为空");
				request.getRequestDispatcher("/regist.jsp").forward(request, response);
				return;
			}
			
			if(phoneNumber==null||phoneNumber.trim().isEmpty()){
				request.setAttribute("msg6", "联系方式不能为空");
				request.getRequestDispatcher("/regist.jsp").forward(request, response);
				return;
			}
			if(!isPhoneLegal(phoneNumber)){
				request.setAttribute("msg6", "联系方式错误");
				request.getRequestDispatcher("/regist.jsp").forward(request, response);
				return;
			}
			
			
			if(passkey==null||passkey.trim().isEmpty()){
				request.setAttribute("msg7", "密码不能为空");
				request.getRequestDispatcher("/regist.jsp").forward(request, response);
				return;
			}
			
			if(!isLength(passkey)) {
				request.setAttribute("msg7", "请输入含有字母和数字的6-20位密码");
				request.getRequestDispatcher("/regist.jsp").forward(request, response);
				return;
			}
			
			if(!passkey.equals(rePasskey)){
				request.setAttribute("msg8", "两次输入的密码不同");
				request.getRequestDispatcher("/regist.jsp").forward(request, response);
				return;
			}
			UserDao u = new UserDao();
			u.addUser(userName,passkey, realName, stuNumber, academy, phoneNumber, department);
			//request.setAttribute("msg", "恭喜："+userName+"，注册成功");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		}	
}



	