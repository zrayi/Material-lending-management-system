package login.LoginRegistServlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import login.mysql.UserDao;

public class LoginServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String userName = request.getParameter("userName");
		String passkey = request.getParameter("passkey");
		String verifyc  = request.getParameter("verifycode");
		String svc =(String) request.getSession().getAttribute("sessionverify");
		String psw =new UserDao().findUsername(userName);
		
		//登录的逻辑控制
		
		if(!svc.equalsIgnoreCase(verifyc)){
			request.setAttribute("userName", userName);
			request.setAttribute("msg1", "* 验证码错误");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return;
		}
		if(psw ==null){
			request.setAttribute("userName", userName);
			request.setAttribute("msg2", "* 用户不存在");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return;
		}
		if(psw!=null&&!psw.equals(passkey)){
			request.setAttribute("userName", userName);
			request.setAttribute("msg3", "* 密码错误");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return;
		}
		if(psw.equals(passkey)){
		  //request.setAttribute("msg", "用户："+userName+",登陆成功");
			request.getRequestDispatcher("/index.jsp").forward(request, response);
			//response.setHeader("Refresh","1;url=index.jsp");
		}
		
	}

}
