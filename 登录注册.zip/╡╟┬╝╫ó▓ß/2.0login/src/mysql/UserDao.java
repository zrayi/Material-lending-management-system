package mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
 
public class UserDao {
	public String findUsername(String userName){
		String psw = null;
		Connection con =null;
		PreparedStatement pstmt =null;
		ResultSet rs = null;
		try {
			String driver ="com.mysql.jdbc.Driver";
			String url ="jdbc:mysql://localhost:3306/iLend?useSSL=false";
			String user ="root";
			String password ="036286";
			Class.forName(driver);
			con = DriverManager.getConnection(url, user, password);
			String sql = "select userName,passkey  from ilend_user where userName=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, userName);
			rs = pstmt.executeQuery();
			if(rs==null){
				return null;
			}
			if(rs.next()){
				psw=rs.getString("passkey");
			}else{
				psw=null;
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt!=null)pstmt.close();
				if(con!=null)con.close();
				} 
			catch (SQLException e) {		
									}
		}
		return psw;
	}
	public void addUser(String userName,String passkey,String realName,String stuNumber,String academy,String phoneNumber,String department){
		Connection con =null;
		PreparedStatement pstmt =null;
		try {
			String driver ="com.mysql.jdbc.Driver";
			String url ="jdbc:mysql://localhost:3306/ilend?useSSL=false";
			String user ="root";
			String password ="036286";//改为自己的用户名密码和数据库名
			Class.forName(driver);
			con = DriverManager.getConnection(url, user, password);
			String sql = "INSERT INTO ilend_user VALUES(?,?,?,?,?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, userName);
			pstmt.setString(2, passkey);
			pstmt.setString(3, realName);
			pstmt.setString(4, stuNumber);
			pstmt.setString(5, academy);
			pstmt.setString(6, phoneNumber);
			pstmt.setString(7, department);
			pstmt.executeUpdate();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt!=null)pstmt.close();
				if(con!=null)con.close();
				} 
			catch (SQLException e) {		
									}
		}
	}
	//单独测试使用
	/*public static void main(String[] args) {
		String psw =new UserDao().findUsername("345");
		System.out.println(psw);
		UserDao u = new UserDao();
		u.addUser("35", "35","比较好","13","背靠背","13","13");
	}*/
}