package login.registServlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mysql.UserDao;

public class RegistServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String userName = request.getParameter("userName");
		String passkey = request.getParameter("passkey");
		String rePasskey = request.getParameter("rePasskey");
		String realName = request.getParameter("realName");
		String stuNumber = request.getParameter("stuNumber");
		String academy = request.getParameter("academy");
		String phoneNumber = request.getParameter("phoneNumber");
		String department = request.getParameter("department");
		if(userName==null||userName.trim().isEmpty()){
			request.setAttribute("msg", "帐号不能为空");
			request.getRequestDispatcher("/regist.jsp").forward(request, response);
			return;
		}
		if(passkey==null||passkey.trim().isEmpty()){
			request.setAttribute("msg", "密码不能为空");
			request.getRequestDispatcher("/regist.jsp").forward(request, response);
			return;
		}
		if(!passkey.equals(rePasskey)){
			request.setAttribute("msg", "两次输入的密码不同");
			request.getRequestDispatcher("/regist.jsp").forward(request, response);
			return;
		}
		if(realName==null||realName.trim().isEmpty()){
			request.setAttribute("msg", "姓名不能为空");
			request.getRequestDispatcher("/regist.jsp").forward(request, response);
			return;
		}
		if(stuNumber==null||stuNumber.trim().isEmpty()){
			request.setAttribute("msg", "学号不能为空");
			request.getRequestDispatcher("/regist.jsp").forward(request, response);
			return;
		}		
		if(academy==null||academy.trim().isEmpty()){
			request.setAttribute("msg", "学院不能为空");
			request.getRequestDispatcher("/regist.jsp").forward(request, response);
			return;
		}
		if(phoneNumber==null||phoneNumber.trim().isEmpty()){
			request.setAttribute("msg", "联系方式不能为空");
			request.getRequestDispatcher("/regist.jsp").forward(request, response);
			return;
		}		
		if(department==null||department.trim().isEmpty()){
			request.setAttribute("msg", "单位不能为空");
			request.getRequestDispatcher("/regist.jsp").forward(request, response);
			return;
		}
		UserDao u = new UserDao();
		u.addUser(userName,passkey, realName, stuNumber, academy, phoneNumber, department);
		//request.setAttribute("msg", "恭喜："+userName+"，注册成功");
		request.getRequestDispatcher("/login.jsp").forward(request, response);

	}

}
