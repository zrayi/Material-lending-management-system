package com.borrow.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.borrow.bean.UserBean;
import com.borrow.dao.UserDao;
import com.borrow.dao.GoodsDao;

public class BorrowServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public BorrowServlet() {
      super();
      // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	// TODO Auto-generated method stub
	//设置编码类型
	request.setCharacterEncoding("UTF-8");
	response.setContentType("text/html;charset=UTF-8");
	//GoodsDao goodsdao = new GoodsDao();

	//获取图书id
	int gNumber = Integer.parseInt(request.getParameter("gNumber"));
	//HttpSession session = request.getSession();
	//UserBean user = new UserBean();
	//session.setAttribute("stuNumber", "2016141098575");
	//获取到存入session的aid读者id
	//String stuNumber = (String)session.getAttribute("stuNumber");
	//String stuNumber = "2016141098575";
	//UserDao userdao = new UserDao();
	//通过aid获取到读者的信息
	//user = userdao.get_stuNumberInfo2(stuNumber);
	//将借阅记录存入数据表
	//goodsdao.borrowGoods(gNumber,user);
	response.sendRedirect("/borrow/get_borrowInfo.jsp?gNumber = "+gNumber);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}