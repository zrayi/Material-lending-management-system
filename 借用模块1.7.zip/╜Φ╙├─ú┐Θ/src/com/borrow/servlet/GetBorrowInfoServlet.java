package com.borrow.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.borrow.dao.BorrowRecordDao;

public class GetBorrowInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	public GetBorrowInfoServlet() {
      super();
      // TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	// TODO Auto-generated method stub
	//	doGet(request, response);
	//填写借用记录信息
	request.setCharacterEncoding("UTF-8");
	response.setContentType("text/html;charset=UTF-8");

	String stuNumber = "2016141098575";

	//int gNumber = Integer.parseInt(request.getParameter("gNumber"));
	int gNumber = 4;
	String oPerson = request.getParameter("oPerson");
	String oPhone = request.getParameter("oPhone");
	String outTime = request.getParameter("outTime");
	String backTime = request.getParameter("backTime");
	String oReason = request.getParameter("oReason");
	
	BorrowRecordDao borrowrecorddao = new BorrowRecordDao();
	borrowrecorddao.insertBorrow(stuNumber,gNumber,oPerson,oPhone,outTime,backTime,oReason);
	response.sendRedirect("/borrow/user_check.jsp");
}

}