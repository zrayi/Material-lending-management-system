package com.borrow.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.borrow.bean.GoodsBean;
import com.borrow.dao.GoodsDao;

public class GoodsInquireServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

  	public GoodsInquireServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		
		String gType = request.getParameter("gType");
		GoodsDao goodsdao = new GoodsDao();
		ArrayList<GoodsBean> inquire_data = goodsdao.getLikeList(gType);
		//将获取的结果存入请求中
		request.setAttribute("inquire_data", inquire_data);
		String url = "";
			url = response.encodeURL("goods_inquire.jsp");
		//将请求转发
	    request.getRequestDispatcher(url).forward(request, response);
	}

}
