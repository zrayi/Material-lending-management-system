package com.borrow.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.borrow.dao.UserDao;
import com.borrow.dao.BorrowRecordDao;

public class CheckServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public CheckServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//设置编码类型
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		BorrowRecordDao recorddao = new BorrowRecordDao();

		//审核功能，获取借阅记录的hid
		//int oNumber = Integer.parseInt(request.getParameter("oNumber"));
		int oNumber = 137;
		String State = request.getParameter("State");
		String outComment = request.getParameter("outComment");
		if(State=="待审核") {
			int oState=1;
		  //调用审核函数，改变oState字段和outComment审核原因
			recorddao.check_BorrowRecord(oNumber,oState,outComment);
		}else if(State=="通过") {
			int oState=2;
		  //调用审核函数，改变oState字段和outComment审核原因
		  recorddao.check_BorrowRecord(oNumber,oState,outComment);
		}else {
			int oState=3;
		  //调用审核函数，改变oState字段和outComment审核原因
			recorddao.check_BorrowRecord(oNumber,oState,outComment);
		}
		response.sendRedirect("admin_check.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
