package com.borrow.bean;

public class GoodsBean {
	/**
	 * 物资的数据表的bean
	 */
	private int gNumber;
	private String gType;//注释
	private String gCondition;
	private String gState;
	private String gPosition;//注释
	private String gDepartment;
	private String gPic;
	private String gRemark;
	public int getgNumber() {
		return gNumber;
	}
	public void setgNumber(int gNumber) {
		this.gNumber = gNumber;
	}
	public String getgType() {
		return gType;
	}
	public void setgType(String gType) {
		this.gType = gType;
	}
	public String getgCondition() {
		return gCondition;
	}
	public void setgCondition(String gCondition) {
		this.gCondition = gCondition;
	}
	public String getgState() {
		return gState;
	}
	public void setgState(String gState) {
		this.gState = gState;
	}
	public String getgPosition() {
		return gPosition;
	}
	public void setgPosition(String gPosition) {
		this.gPosition = gPosition;
	}
	public String getgDepartment() {
		return gDepartment;
	}
	public void setgDepartment(String gDepartment) {
		this.gDepartment = gDepartment;
	}
	public String getgPic() {
		return gPic;
	}
	public void setgPic(String gPic) {
		this.gPic = gPic;
	}
	public String getgRemark() {
		return gRemark;
	}
	public void setgRemark(String gRemark) {
		this.gRemark = gRemark;
	}
}
