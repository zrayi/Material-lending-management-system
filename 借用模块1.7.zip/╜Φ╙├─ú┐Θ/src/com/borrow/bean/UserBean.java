package com.borrow.bean;

public class UserBean {
	/**
	 * 用户的数据表的bean
	 */
	private String stuNumber;//id，学号
	private String userName;//用户名（邮箱或者电话）
	private String realName;//真实姓名
	private String passKey;//登录密码
	private String phoneNumber;//电话
	private String academy;//学院
	private String department;//所在部门或社团
	private int userType;//用来判断是物资管理者还是使用者，管理者的值为1，使用者为2

	public String getstuNumber() {
		return stuNumber;
	}
	public void setstuNumber(String stuNumber) {
		this.stuNumber = stuNumber;
	}

	public String getuserName() {
		return userName;
	}
	public void setuserName(String userName) {
		this.userName = userName;
	}

	public String getrealName() {
		return realName;
	}
	public void setrealName(String realName) {
		this.realName = realName;
	}

	public String getpassKey() {
		return passKey;
	}
	public void setpassKey(String passKey) {
		this.passKey = passKey;
	}

	public String getphoneNumber() {
		return phoneNumber;
	}
	public void setphoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getacademy() {
		return academy;
	}
	public void setacademy(String academy) {
		this.academy = academy;
	}

	public String getdepartment() {
		return department;
	}
	public void setdepartment(String department) {
		this.department = department;
	}

	public int getuserType() {
		return userType;
	}
	public void setuserType(int userType) {
		this.userType = userType;
	}
	
}
