package com.borrow.bean;

public class BorrowRecordBean {
	/**
	 * 物资借用记录的数据表的bean
	 */
	private int oNumber;//借还记录的id
	private String stuNumber;//使用者id
	private int gNumber;//物资id
	private String gType;//物资类型
	private String oOut;//借出单位
	private String oIn;//借入单位
	private String oPerson;//借入负责人
	private String oPhone;//借用人联系方式
	private String outTime;//借出时间
	private String backTime;//预计归还时间
	private String realBackTime;//实际归还时间
	private int oState;//表示审核、使用状态，0为已完成，1为待审核，2为借用中，3为审核未通过
	private String oReason;//借用原因
	private String outComment;//备注

	public int getoNumber() {
		return oNumber;
	}
	public void setoNumber(int oNumber) {
		this.oNumber = oNumber;
	}
	public String getstuNumber() {
		return stuNumber;
	}
	public void setstuNumber(String stuNumber) {
		this.stuNumber = stuNumber;
	}
	public int getgNumber() {
		return gNumber;
	}
	public void setgNumber(int gNumber) {
		this.gNumber = gNumber;
	}
	public String getgType() {
		return gType;
	}
	public void setogType(String gType) {
		this.gType = gType;
	}
	public String getoOut() {
		return oOut;
	}
	public void setoOut(String oOut) {
		this.oOut = oOut;
	}
	public String getoIn() {
		return oIn;
	}
	public void setoIn(String oIn) {
		this.oIn = oIn;
	}
	public String getoPerson() {
		return oPerson;
	}
	public void setoPerson(String oPerson) {
		this.oPerson = oPerson;
	}
	public String getoPhone() {
		return oPhone;
	}
	public void setoPhone(String oPhone) {
		this.oPhone = oPhone;
	}
	public String getoutTime() {
		return outTime;
	}
	public void setoutTime(String outTime) {
		this.outTime = outTime;
	}
	public String getbackTime() {
		return backTime;
	}
	public void setbackTime(String backTime) {
		this.backTime = backTime;
	}

	public String getrealBackTime() {
		return realBackTime;
	}
	public void setrealBackTime(String realBackTime) {
		this.realBackTime = realBackTime;
	}

	public int getoState() {
		return oState;
	}
	public void setoState(int oState) {
		this.oState = oState;
	}

	public String getoReason() {
		return oReason;
	}
	public void setoReason(String oReason) {
		this.oReason = oReason;
	}
	public String getoutComment() {
		return outComment;
	}
	public void setoutComment(String outComment) {
		this.outComment = outComment;
	}
	
}
