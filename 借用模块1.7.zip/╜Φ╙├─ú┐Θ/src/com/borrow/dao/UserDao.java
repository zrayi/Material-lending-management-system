package com.borrow.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.borrow.util.DBUtil;
import com.borrow.bean.UserBean;

public class UserDao {
	/**
	 * 根据传入的账号，密码，来查找对应的读者信息，返回一个AdminBean类型，
	 * @param userName
	 * @param passKey
	 * @return
	 */
	public UserBean getUserInfo(String userName, String passKey) {
		// TODO Auto-generated method stub
		UserBean userbean = new UserBean();
		Connection conn = DBUtil.getConnectDb();
		String sql = "select stuNumber,userName,realName,passKey,phoneNumber,academy,department from iLend_user where userName="+userName+" AND passKey="+passKey;
		PreparedStatement stm = null;
		ResultSet rs = null;
		try {
			stm = conn.prepareStatement(sql);
			rs = stm.executeQuery();
			if(rs.next()){
				userbean.setstuNumber(rs.getString("stuNumber"));
				userbean.setuserName(rs.getString("userName"));
				userbean.setrealName(rs.getString("realName"));
				userbean.setpassKey(rs.getString("passKey"));
				userbean.setphoneNumber(rs.getString("phoneNumber"));
				userbean.setacademy(rs.getString("academy"));
				userbean.setdepartment(rs.getString("department"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.CloseDB(rs, stm, conn);
		}
		return userbean;
	}

	/**
	 * 获取全部用户的信息，其中sql语句中的status=1，表示只查找读者，不显示管理员的
	 * @return
	 */
	public ArrayList<UserBean> get_ListInfo(){
		ArrayList<UserBean> tag_Array = new ArrayList<UserBean>();
		Connection conn = DBUtil.getConnectDb();
		String sql = "select stuNumber,userName,realName,passKey,phoneNumber,academy,department from iLend_user where userType=2";
		PreparedStatement stm = null;
		ResultSet rs = null;
		try {
			stm = conn.prepareStatement(sql);
			rs = stm.executeQuery();
			while(rs.next()){
				UserBean userbean = new UserBean();
				userbean.setstuNumber(rs.getString("stuNumber"));
				userbean.setuserName(rs.getString("userName"));
				userbean.setrealName(rs.getString("realName"));
				userbean.setpassKey(rs.getString("passKey"));
				userbean.setphoneNumber(rs.getString("phoneNumber"));
				userbean.setacademy(rs.getString("academy"));
				userbean.setdepartment(rs.getString("department"));
				tag_Array.add(userbean);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.CloseDB(rs, stm, conn);
		}
		return tag_Array;
	}
	/**
	 * 根据传入的stuNumber，查找到对应的使用者的全部信息，返回一个UserBean类型的数据
	 * @param stuNumber
	 * @return
	 */
	public UserBean get_stuNumberInfo(int stuNumber){
		UserBean userbean = new UserBean();
		Connection conn = DBUtil.getConnectDb();
		String sql = "select stuNumber,userName,realName,passKey,phoneNumber,academy,department from iLend_user where stuNumber="+stuNumber;
		PreparedStatement stm = null;
		ResultSet rs = null;
		try {
			stm = conn.prepareStatement(sql);
			rs = stm.executeQuery();
			if(rs.next()){
				userbean.setstuNumber(rs.getString("stuNumber"));
				userbean.setuserName(rs.getString("userName"));
				userbean.setrealName(rs.getString("realName"));
				userbean.setpassKey(rs.getString("passKey"));
				userbean.setphoneNumber(rs.getString("phoneNumber"));
				userbean.setacademy(rs.getString("academy"));
				userbean.setdepartment(rs.getString("department"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.CloseDB(rs, stm, conn);
		}
		return userbean;
	}
	/**
	 * 根据传入的stuNumber，查找到对应的使用者的全部信息，返回一个UserBean类型的数据，与上一个相似，只是stuNumber的类型为String，
	 * @param stuNumber
	 * @return
	 */
	public UserBean get_stuNumberInfo2(String stuNumber){
		UserBean userbean = new UserBean();
		Connection conn = DBUtil.getConnectDb();
		String sql = "select stuNumber,userName,realName,passKey,phoneNumber,academy,department from iLend_user where stuNumber="+stuNumber;
		PreparedStatement stm = null;
		ResultSet rs = null;
		try {
			stm = conn.prepareStatement(sql);
			rs = stm.executeQuery();
			if(rs.next()){
				userbean.setstuNumber(rs.getString("stuNumber"));
				userbean.setuserName(rs.getString("userName"));
				userbean.setrealName(rs.getString("realName"));
				userbean.setpassKey(rs.getString("passKey"));
				userbean.setphoneNumber(rs.getString("phoneNumber"));
				userbean.setacademy(rs.getString("academy"));
				userbean.setdepartment(rs.getString("department"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.CloseDB(rs, stm, conn);
		}
		return userbean;
	}
}
