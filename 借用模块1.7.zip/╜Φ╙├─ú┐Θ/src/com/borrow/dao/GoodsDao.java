package com.borrow.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;

import com.borrow.bean.GoodsBean;
import com.borrow.util.DBUtil;
import com.borrow.bean.UserBean;

public class GoodsDao {
	/**
	*获取所有物资的信息
	*/
	public ArrayList<GoodsBean> get_ListInfo(){
		ArrayList<GoodsBean> tag_Array = new ArrayList<GoodsBean>();
		Connection conn = DBUtil.getConnectDb();
		String sql = "select gNumber,gType,gPosition,gDepartment from iLend_goods";
		PreparedStatement stm = null;
		ResultSet rs = null;
		try {
			stm = conn.prepareStatement(sql);
			rs = stm.executeQuery();
			while(rs.next()){
				GoodsBean tag = new GoodsBean();
				tag.setgNumber(rs.getInt("gNumber"));
				tag.setgType(rs.getString("gType"));
				tag.setgPosition(rs.getString("gPosition"));
				tag.setgDepartment(rs.getString("gDepartment"));
				tag_Array.add(tag);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.CloseDB(rs, stm, conn);
		}
		return tag_Array;
	}
	/**
	*根据输入的物资类型查询物资信息
	*/
	public ArrayList<GoodsBean> getLikeList(String gType) {
		// TODO Auto-generated method stub
		ArrayList<GoodsBean> tag_Array = new ArrayList<GoodsBean>();
		Connection conn = DBUtil.getConnectDb();
		String sql = "select gNumber,gType,gPosition,gDepartment from iLend_goods where gType like '%"+gType+"%'";
		PreparedStatement stm = null;
		ResultSet rs = null;
		try {
			stm = conn.prepareStatement(sql);
			rs = stm.executeQuery();
			while(rs.next()){
				GoodsBean tag = new GoodsBean();
				tag.setgNumber(rs.getInt("gNumber"));
				tag.setgType(rs.getString("gType"));
				tag.setgPosition(rs.getString("gPosition"));
				tag.setgDepartment(rs.getString("gDepartment"));
				tag_Array.add(tag);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.CloseDB(rs, stm, conn);
		}
		return tag_Array;
	}

	/**
	 * 获取单个图书的信息，根据传入的gNumber来查找，返回一个GoodsBean数据类型
	 * @param gNumber
	 * @return
	 */
	public GoodsBean get_GoodsInfo(int gNumber){
		GoodsBean tag = new GoodsBean();
		Connection conn = DBUtil.getConnectDb();
		String sql = "select gNumber,gType,gPosition,gDepartment from iLend_goods where gNumber="+gNumber;
		PreparedStatement stm = null;
		ResultSet rs = null;
		try {
			stm = conn.prepareStatement(sql);
			rs = stm.executeQuery();
			while(rs.next()){
				tag.setgNumber(rs.getInt("gNumber"));
				tag.setgType(rs.getString("gType"));
				tag.setgPosition(rs.getString("gPosition"));
				tag.setgDepartment(rs.getString("gDepartment"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.CloseDB(rs, stm, conn);
		}
		return tag;
	}
	
	/**
	 * 物资借用函数，根据传入gNumber物资id，userbean当前登录用户的信息，在借还记录数据表中新插入一条记录
	 */
	public void borrowGoods(int gNumber, UserBean userbean) {
		// TODO Auto-generated method stub
		GoodsBean goodsbean = new GoodsBean();
		goodsbean = this.get_GoodsInfo(gNumber);
		//生成日期的功能
		Calendar c = Calendar.getInstance();
		int year = c.get(Calendar.YEAR);  
		int month = c.get(Calendar.MONTH);   
		int day = c.get(Calendar.DATE);  
		//生成借阅开始日期
		String outTime = ""+year+"-"+month+"-"+day;
		day = day + 3;
		//生成截止还书日期
		String backTime = ""+year+"-"+month+"-"+day;
		String realBackTime = backTime;
		Connection conn = DBUtil.getConnectDb();
		String sql = "insert into iLend_borrow(stuNumber,gNumber,gType,oOut,oIn,outTime,backTime,oState) values(?,?,?,?,?,?,?,?)";
		int rs = 0;
		PreparedStatement stm = null;
		try {
			stm = conn.prepareStatement(sql);
			stm.setString(1, userbean.getstuNumber());
			stm.setInt(2, goodsbean.getgNumber());
			stm.setString(3, goodsbean.getgType());
			stm.setString(4, goodsbean.getgDepartment());
			stm.setString(5, userbean.getdepartment());
			stm.setString(6, outTime);
			stm.setString(7, backTime);
			stm.setInt(8, 1);
			rs = stm.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
