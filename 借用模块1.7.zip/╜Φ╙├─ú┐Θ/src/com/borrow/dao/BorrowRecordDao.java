package com.borrow.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;

import com.borrow.bean.UserBean;
import com.borrow.bean.GoodsBean;
import com.borrow.bean.BorrowRecordBean;
import com.borrow.dao.GoodsDao;
import com.borrow.dao.UserDao;
import com.borrow.util.DBUtil;


public class BorrowRecordDao {
	
	/**
	 * 获取借阅记录的全部信息，无传值，表示搜索待审核的，或者正在使用的，或者已经完成的信息
	 * 
	 * @return
	 */
	public ArrayList<BorrowRecordBean> get_BorrowRecordListInfo3(){
		ArrayList<BorrowRecordBean> tag_Array = new ArrayList<BorrowRecordBean>();
		Connection conn = DBUtil.getConnectDb();
		String sql = "select oNumber,stuNumber,gNumber,gType,oOut,oIn,oPerson,oPhone,outTime,backTime,realBackTime,oReason,outComment from iLend_borrow";
		PreparedStatement stm = null;
		ResultSet rs = null;
		try {
			stm = conn.prepareStatement(sql);
			rs = stm.executeQuery();
			while(rs.next()){
				BorrowRecordBean tag = new BorrowRecordBean();
				tag.setoNumber(rs.getInt("oNumber"));
				tag.setstuNumber(rs.getString("stuNumber"));
				tag.setgNumber(rs.getInt("gNumber"));
				tag.setogType(rs.getString("gType"));
				tag.setoOut(rs.getString("oOut"));
				tag.setoIn(rs.getString("oIn"));
				tag.setoPerson(rs.getString("oPerson"));
				tag.setoPhone(rs.getString("oPhone"));
				tag.setoutTime(rs.getString("outTime"));
				tag.setbackTime(rs.getString("backTime"));
				tag.setrealBackTime(rs.getString("realBackTime"));
				tag.setoReason(rs.getString("oReason"));
				tag.setoutComment(rs.getString("outComment"));
				tag_Array.add(tag);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.CloseDB(rs, stm, conn);
		}
		return tag_Array;
	}
	/**
	 * 获取借阅记录的全部信息，传入的条件有oState，表示搜索待审核的，或者正在使用的，或者已经完成的信息
	 * @param oState
	 * @return
	 */
	public ArrayList<BorrowRecordBean> get_BorrowRecordListInfo2(int oState){
		ArrayList<BorrowRecordBean> tag_Array = new ArrayList<BorrowRecordBean>();
		Connection conn = DBUtil.getConnectDb();
		String sql = "select oNumber,stuNumber,gNumber,gType,oOut,oIn,oPerson,oPhone,outTime,backTime,realBackTime,oReason,outComment from iLend_borrow where oState="+oState;
		PreparedStatement stm = null;
		ResultSet rs = null;
		try {
			stm = conn.prepareStatement(sql);
			rs = stm.executeQuery();
			while(rs.next()){
				BorrowRecordBean tag = new BorrowRecordBean();
				tag.setoNumber(rs.getInt("oNumber"));
				tag.setstuNumber(rs.getString("stuNumber"));
				tag.setgNumber(rs.getInt("gNumber"));
				tag.setogType(rs.getString("gType"));
				tag.setoOut(rs.getString("oOut"));
				tag.setoIn(rs.getString("oIn"));
				tag.setoPerson(rs.getString("oPerson"));
				tag.setoPhone(rs.getString("oPhone"));
				tag.setoutTime(rs.getString("outTime"));
				tag.setbackTime(rs.getString("backTime"));
				tag.setrealBackTime(rs.getString("realBackTime"));
				tag.setoReason(rs.getString("oReason"));
				tag.setoutComment(rs.getString("outComment"));
				tag_Array.add(tag);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.CloseDB(rs, stm, conn);
		}
		return tag_Array;
	}

	/**
	 * 获取借还记录的信息，传入的条件有oState，stuNumber，表示搜索正在借阅的，或者已经还书的信息，stuNumber代表当前登录用户
	 * @param oState
	 * @return
	 */
	public ArrayList<BorrowRecordBean> get_BorrowRecordListInfo(int oState,String stuNumber){
		ArrayList<BorrowRecordBean> tag_Array = new ArrayList<BorrowRecordBean>();
		Connection conn = DBUtil.getConnectDb();
		String sql = "select oNumber,stuNumber,gNumber,gType,oOut,oIn,oPerson,oPhone,outTime,backTime,realBackTime,oReason,outComment from iLend_borrow where oState="+oState+"and stuNumber="+stuNumber;
		PreparedStatement stm = null;
		ResultSet rs = null;
		try {
			stm = conn.prepareStatement(sql);
			rs = stm.executeQuery();
			while(rs.next()){
				BorrowRecordBean tag = new BorrowRecordBean();
				tag.setoNumber(rs.getInt("oNumber"));
				tag.setstuNumber(rs.getString("stuNumber"));
				tag.setgNumber(rs.getInt("gNumber"));
				tag.setogType(rs.getString("gType"));
				tag.setoOut(rs.getString("oOut"));
				tag.setoIn(rs.getString("oIn"));
				tag.setoPerson(rs.getString("oPerson"));
				tag.setoPhone(rs.getString("oPhone"));
				tag.setoutTime(rs.getString("outTime"));
				tag.setbackTime(rs.getString("backTime"));
				tag.setrealBackTime(rs.getString("realBackTime"));
				tag.setoReason(rs.getString("oReason"));
				tag.setoutComment(rs.getString("outComment"));
				tag_Array.add(tag);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.CloseDB(rs, stm, conn);
		}
		return tag_Array;
	}

	/**
	 * 表单添加借用记录信息
	 */
	public void insertBorrow(String stuNumber,int gNumber,String oPerson,String oPhone,String outTime,String backTime,String oReason) {
		GoodsBean goodsbean = new GoodsBean();
		UserBean userbean = new UserBean();
		UserDao userdao = new UserDao();
		GoodsDao goodsdao = new GoodsDao();
		userbean = userdao.get_stuNumberInfo2(stuNumber);
		goodsbean = goodsdao.get_GoodsInfo(gNumber);
		Connection conn = DBUtil.getConnectDb();
		String sql = "insert into iLend_borrow(stuNumber,gNumber,gType,oOut,oIn,oPerson,oPhone,outTime,backTime,oState,oReason) values(?,?,?,?,?,?,?,?,?,?,?)";
		int rs = 0;
		PreparedStatement stm = null;
		try {
			stm = conn.prepareStatement(sql);
			stm.setString(1, userbean.getstuNumber());
			stm.setInt(2, goodsbean.getgNumber());
			stm.setString(3, goodsbean.getgType());
			stm.setString(4, goodsbean.getgDepartment());
			stm.setString(5, userbean.getdepartment());
			stm.setString(6, oPerson);
			stm.setString(7, oPhone);
			stm.setString(8, outTime);
			stm.setString(9, backTime);
			stm.setInt(10, 1);
			stm.setString(11, oReason);
			rs = stm.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void check_BorrowRecord(int oNumber,int oState, String outComment) {
		Connection conn = DBUtil.getConnectDb();
		String sql = "update iLend_borrow set oState=?,outComment=? where oNumber=?";
		PreparedStatement stm = null;
		try {
			stm = conn.prepareStatement(sql);
			stm.setInt(1, oState);
			stm.setString(2, outComment);
			stm.setInt(3, oNumber);
			stm.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * 修改图书的信息，bid作为条件，
	 */
	/*insertBorrow(gNumber,oPerson,oPhone,outTime,backTime,oReason)
	public void updateBook(int bid, String card, String name, String type, String autho, String press, int num) {
		// TODO Auto-generated method stub
		Connection conn = DBUtil.getConnectDb();
		String sql = "update book set name=?,card=?,type=?,autho=?,press=?,num=? where bid=?";
		PreparedStatement stm = null;
		try {
			stm = conn.prepareStatement(sql);
			stm.setString(1, name);
			stm.setString(2, card);
			stm.setString(3, type);
			stm.setString(4, autho);
			stm.setString(5, press);
			stm.setInt(6, num);
			stm.setInt(7, bid);
			stm.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
	
}
